package com.cognizant.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.*;

import com.cognizant.dto.AddReservationDTO;
import com.cognizant.exception.DocumentSizeLimitExceededException;
import com.cognizant.exception.EntityBudgetLimitExceededException;
import com.cognizant.utilities.ValidateReservation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.ReservationTypes;
import com.cognizant.entities.Reservations;
import com.cognizant.repositories.ReservationDocsRepository;
import com.cognizant.repositories.ReservationTypesRepository;
import com.cognizant.repositories.ReservationsRepository;
import com.cognizant.services.ReservationsServiceImpl;
import com.cognizant.mapper.ReservationsMapper;


class TestReservationsService {

	@Mock
	ReservationsRepository reservationsRepository;
	
	@Mock
	ReservationDocsRepository reservationDocsRepository;
	
	@Mock
	ReservationTypesRepository reservationTypesRepository;
	
	@Mock
	ReservationsMapper reservationsMapper;

	@Mock
	ValidateReservation validateReservation;
	
	@InjectMocks
	ReservationsServiceImpl reservationsServiceImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getReservationsByReservationId_Positive() {
    	Reservations mockReservation=new Reservations();
    	mockReservation.setId(1);
    	mockReservation.setReservationDoneByEmployeeId(110123);
    	mockReservation.setTravelRequestId(5);
    	
    	ReservationTypes reservationTypes=new ReservationTypes();
    	reservationTypes.setTypeId(5);
    	
    	reservationTypes.setTypeName("hotel");
    	
    	mockReservation.setReservationTypes(reservationTypes);
    	mockReservation.setReservationDate(LocalDate.of(2024,03,19));
    	mockReservation.setCreatedOn(LocalDate.of(2024,03,19));
    	mockReservation.setReservationDoneWithEntity("hotel");
    	mockReservation.setAmount(1000);
    	mockReservation.setConfirmationID("899");
    	mockReservation.setRemarks("successful");
		
    	Optional<Reservations> optionalOfReservations = Optional.of(mockReservation);
        when(reservationsRepository.findById(mockReservation.getId())).thenReturn(optionalOfReservations);

        ReservationsDTO mockReservationDTO = new ReservationsDTO();
        when(reservationsMapper.toReservationDto(mockReservation)).thenReturn(mockReservationDTO);

        ReservationsDTO result = reservationsServiceImpl.findReservationByReservationId(1);
        assertNotNull(result);
    }
    @Test
    void getReservationsByReservationId_Negative() {
    	Reservations mockReservation=new Reservations();
    	
    	Optional<Reservations> optionalOfReservations = Optional.empty();
        when(reservationsRepository.findById(2)).thenReturn(optionalOfReservations);
        
        ReservationsDTO mockReservationDTO = new ReservationsDTO();
        when(reservationsMapper.toReservationDto(mockReservation)).thenReturn(mockReservationDTO);

        ReservationsDTO result = reservationsServiceImpl.findReservationByReservationId(2);
        assertNull(result);
    }
    
    @Test
    void findReservationsByTravelRequestId_Positive() {
    	List<Reservations> mockReservationIterable = new ArrayList<Reservations>();
    	Reservations reservations1=new Reservations();
    	reservations1.setReservationDoneByEmployeeId(201002);
    	reservations1.setTravelRequestId(12);
    	ReservationTypes reservationTypes=new ReservationTypes();
    	reservationTypes.setTypeId(1);
    	reservationTypes.setTypeName("flight");
    	
    	reservations1.setReservationTypes(reservationTypes);
    	reservations1.setCreatedOn(LocalDate.now());
    	reservations1.setReservationDoneWithEntity("flight");
    	reservations1.setReservationDate(LocalDate.of(2024, 4, 10));
    	reservations1.setAmount(15000);
    	reservations1.setConfirmationID("1345");
    	reservations1.setRemarks("Flight Booking");
    	
    	Reservations reservations2=new Reservations();
    	reservations2.setReservationDoneByEmployeeId(201002);
    	reservations2.setTravelRequestId(12);
    	
    	ReservationTypes reservationTypes2=new ReservationTypes();
    	reservationTypes2.setTypeId(4);
    	reservationTypes2.setTypeName("cab");
    	
    	reservations2.setReservationTypes(reservationTypes);
    	reservations2.setCreatedOn(LocalDate.now());
    	reservations2.setReservationDoneWithEntity("cab");
    	reservations2.setReservationDate(LocalDate.of(2024, 4, 11));
    	reservations2.setAmount(8000);
    	reservations2.setConfirmationID("1320");
    	reservations2.setRemarks("Cab Booking");
    	

    	mockReservationIterable.add(reservations1);
    	mockReservationIterable.add(reservations2);
    	when(reservationsRepository.findByTravelRequestId(12)).thenReturn(mockReservationIterable);

        ReservationsDTO mockReservationDTO1 = new ReservationsDTO();
        ReservationsDTO mockReservationDTO2 = new ReservationsDTO();
        when(reservationsMapper.toReservationDto(reservations1)).thenReturn(mockReservationDTO1);
        when(reservationsMapper.toReservationDto(reservations2)).thenReturn(mockReservationDTO2);

        List<ReservationsDTO> result = reservationsServiceImpl.findReservationsByTravelRequestId(12);
        assertNotNull(result);
    }
    
    @Test
    void findReservationsByTravelRequestId_Negative() {
    	List<Reservations> mockReservationIterable = new ArrayList<Reservations>();
    	Reservations reservations1=new Reservations();
    	Reservations reservations2=new Reservations();
    	mockReservationIterable.add(reservations1);
    	mockReservationIterable.add(reservations2);
    	when(reservationsRepository.findByTravelRequestId(12)).thenReturn(Collections.emptyList());
    	ReservationsDTO mockReservationDTO1 = new ReservationsDTO();
        ReservationsDTO mockReservationDTO2 = new ReservationsDTO();
        when(reservationsMapper.toReservationDto(reservations1)).thenReturn(mockReservationDTO1);
        when(reservationsMapper.toReservationDto(reservations2)).thenReturn(mockReservationDTO2);
        List<ReservationsDTO> result = reservationsServiceImpl.findReservationsByTravelRequestId(12);
        assertNotNull(result); 
    }
	@Test
	void testAddReservations_DocumentSizeLimitExceededException() {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(anyList())).thenReturn(false);
		assertThrows(DocumentSizeLimitExceededException.class, () -> {
			reservationsServiceImpl.addReservations(addReservationDTO);
		});
	}
	@Test
	void testAddReservations_FormatFailure() throws EntityBudgetLimitExceededException,DocumentSizeLimitExceededException{
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		List<String> documentURLs=new ArrayList<>();
		documentURLs.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLs.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLs.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.jpg");
		addReservationDTO.setDocumentURLS(documentURLs);
		when(validateReservation.containsPdf(anyList())).thenReturn(false);
		assertEquals("formatfailure",reservationsServiceImpl.addReservations(addReservationDTO));
	}

	@Test
	void testAddReservations_DuplicateFlightFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("flight");
		addReservationDTO.setAmount(1000);
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(),addReservationDTO.getReservationDoneWithEntity())).thenReturn("flight reservation done");
		String result=reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("duplicateflightfailure",result);
	}
	@Test
	void testAddReservations_DuplicateTrainFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(13);
		addReservationDTO.setReservationDoneWithEntity("train");
		addReservationDTO.setFromDate(LocalDate.of(2024,12,12));
		addReservationDTO.setReservationDate(LocalDate.of(2024,12,11));
		addReservationDTO.setAmount(1000);
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(),addReservationDTO.getReservationDoneWithEntity())).thenReturn("train reservation done");
		String result=reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("duplicatetrainfailure",result);
	}
	@Test
	void testAddReservations_DuplicateBusFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("bus");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024,12,11));
		addReservationDTO.setFromDate(LocalDate.of(2024,12,12));
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("bus reservation done");
		String result = reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("duplicatebusfailure", result);
	}
	@Test
	void testAddReservations_DuplicateCabFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(15);
		addReservationDTO.setReservationDoneWithEntity("cab");
		addReservationDTO.setAmount(1000);
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("cab reservation done");
		String result = reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("duplicatecabfailure", result);
	}
	@Test
	void testAddReservations_DuplicateHotelFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("hotel");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024,12,12));
		addReservationDTO.setFromDate(LocalDate.of(2024,12,12));
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("hotel reservation done");
		String result = reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("duplicatehotelfailure", result);
	}
	@Test
	void testAddReservations_TestTravelReservationsDone() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("hotel");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024,12,12));
		addReservationDTO.setFromDate(LocalDate.of(2024,12,12));
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("travelreservationsdone");
		String result = reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("travelreservationsdone",result);
	}
	@Test
	void testAddReservations_TestTravelReservationsFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("hotel");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024,12,12));
		addReservationDTO.setFromDate(LocalDate.of(2024,12,12));
		List<String> documentURLS=new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("more than 3 reservations");
		String result = reservationsServiceImpl.addReservations(addReservationDTO);
		assertEquals("totalreservationsfailure", result);
	}
	@Test
	void testAddReservations_TrainReservationDateFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("train");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024, 12, 12));
		addReservationDTO.setFromDate(LocalDate.of(2024, 11, 12));
		List<String> documentURLS = new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("success");
		assertThrows(IllegalArgumentException.class, () -> reservationsServiceImpl.addReservations(addReservationDTO));

	}
	@Test
	void testAddReservations_BusReservationDateFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("bus");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024, 12, 12));
		addReservationDTO.setFromDate(LocalDate.of(2024, 11, 12));
		List<String> documentURLS = new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("success");
		assertThrows(IllegalArgumentException.class, () -> reservationsServiceImpl.addReservations(addReservationDTO));

	}
	@Test
	void testAddReservations_HotelReservationDateFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("hotel");
		addReservationDTO.setAmount(1000);
		addReservationDTO.setReservationDate(LocalDate.of(2024, 12, 12));
		addReservationDTO.setFromDate(LocalDate.of(2024, 11, 12));
		List<String> documentURLS = new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("success");
		assertThrows(IllegalArgumentException.class, () -> reservationsServiceImpl.addReservations(addReservationDTO));

	}
	@Test
	void testAddReservations_BudgetLimitExceeded() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("flight");
		addReservationDTO.setAmount(20000);
		addReservationDTO.setReservationDate(LocalDate.of(2024, 12, 12));
		addReservationDTO.setFromDate(LocalDate.of(2024, 11, 12));
		List<String> documentURLS = new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("success");
		assertThrows(EntityBudgetLimitExceededException.class, () -> reservationsServiceImpl.addReservations(addReservationDTO));
	}
	@Test
	void testAddReservations_Failure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
		AddReservationDTO addReservationDTO = new AddReservationDTO();
		addReservationDTO.setReservationDoneByEmployeeId(1);
		addReservationDTO.setTravelRequestId(12);
		addReservationDTO.setReservationDoneWithEntity("flight");
		addReservationDTO.setAmount(2500); // Set an amount that is more than 70% of the budget
		addReservationDTO.setReservationDate(LocalDate.of(2024, 12, 12));
		addReservationDTO.setFromDate(LocalDate.of(2024, 12, 12));
		List<String> documentURLS = new ArrayList<>();
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		documentURLS.add("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
		addReservationDTO.setDocumentURLS(documentURLS);
		Reservations reservation1 = new Reservations();
		reservation1.setAmount(10000);
		reservation1.setReservationDoneWithEntity("hotel");
		Reservations reservation2 = new Reservations();
		reservation2.setAmount(10000);
		reservation2.setReservationDoneWithEntity("cab");
		when(validateReservation.containsPdf(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.validateRecord(addReservationDTO.getDocumentURLS())).thenReturn(true);
		when(validateReservation.totalCheckReservations(addReservationDTO.getTravelRequestId(), addReservationDTO.getReservationDoneWithEntity())).thenReturn("success");
		when(reservationsRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId())).thenReturn(Arrays.asList(reservation1, reservation2));
		assertEquals("failure", reservationsServiceImpl.addReservations(addReservationDTO));
	}
















}
