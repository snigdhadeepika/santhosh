package com.cognizant.service;

import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.ReservationDocs;
import com.cognizant.entities.Reservations;
import com.cognizant.repositories.ReservationDocsRepository;
import com.cognizant.services.ReservationDocsServiceImpl;
import com.cognizant.services.ReservationsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import javax.net.ssl.HttpsURLConnection;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;


class TestReservationDocsService {

    @Mock
    private ReservationDocsRepository reservationDocsRepository;

    @Mock
    private ReservationsService reservationsService;

    @InjectMocks
    private ReservationDocsServiceImpl reservationDocsServiceImpl;

    @BeforeEach
    public void setup(){
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testGetDownloadReservation_WithExistingReservationDocs() throws IOException {
        List<ReservationDocs> reservationDocsList=new ArrayList<>();
        ReservationDocs reservationDocs1=new ReservationDocs();
        reservationDocs1.setId(1);
        reservationDocs1.setDocumentURL("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
        Reservations reservations1=new Reservations();
        reservations1.setId(1);
        reservations1.setReservationDoneByEmployeeId(2317156);
        reservations1.setTravelRequestId(21);
        reservations1.setCreatedOn(LocalDate.of(2024,12,12));
        reservations1.setReservationDoneWithEntity("flight");
        reservations1.setReservationDate(LocalDate.of(2024,12,12));
        reservations1.setConfirmationID("144");
        reservations1.setAmount(1000);
        reservations1.setRemarks("flight booking");
        reservationDocs1.setReservations(reservations1);
        ReservationDocs reservationDocs2=new ReservationDocs();
        reservationDocs2.setId(1);
        reservationDocs2.setDocumentURL("https://www.w3.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf");
        Reservations reservations2=new Reservations();
        reservations2.setId(2);
        reservations2.setReservationDoneByEmployeeId(2317156);
        reservations2.setTravelRequestId(21);
        reservations2.setCreatedOn(LocalDate.of(2024,12,12));
        reservations2.setReservationDoneWithEntity("bus");
        reservations2.setReservationDate(LocalDate.of(2024,12,12));
        reservations2.setConfirmationID("144");
        reservations2.setAmount(1000);
        reservations2.setRemarks("bus booking");
        reservationDocs2.setReservations(reservations2);
        reservationDocsList.add(reservationDocs1);
        reservationDocsList.add(reservationDocs2);

        when(reservationDocsRepository.findAll()).thenReturn(reservationDocsList);
        when(reservationsService.findReservationByReservationId(anyInt())).thenReturn(new ReservationsDTO());
        List<File> downloadFiles=reservationDocsServiceImpl.getDownloadReservation(1);
        assertEquals(2,downloadFiles.size());


    }
    @Test
    void testGetDocumentContent_WithFileUrl() throws IOException{
        Path path= Paths.get("src/test/resources/test-document.pdf");
        String documentURL=path.toAbsolutePath().toString();
        byte[] content=reservationDocsServiceImpl.getDocumentContent(documentURL);
        assertNull(content);
    }
    @Test
    void testGetDocumentContent_WithInvalidUrl() throws Exception{
        String documentURL="https://www.w2.org//WAI//ER//tests//xhtml//testfiles//resources//pdf//dummy.pdf";
        byte[] content=reservationDocsServiceImpl.getDocumentContent(documentURL);
        assertEquals(null,content);
    }
}
