package com.cognizant.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cognizant.dto.ReservationTypesDTO;
import com.cognizant.entities.ReservationTypes;
import com.cognizant.repositories.ReservationTypesRepository;
import com.cognizant.services.ReservationTypesServiceImpl;

class TestReservationTypesService {
	
	@Mock
	ReservationTypesRepository reservationTypesRepository;
	
	@InjectMocks
	ReservationTypesServiceImpl reservationTypesServiceImpl;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    
    @Test
    void fetchAllReservationTypes_Positive() {
    	List<ReservationTypes> mockReservationTypesIterable = new ArrayList<ReservationTypes>();
    	ReservationTypes reservationTypes1 = new ReservationTypes();
    	reservationTypes1.setTypeId(1);
    	reservationTypes1.setTypeName("flight");
    	ReservationTypes reservationTypes2 = new  ReservationTypes();
    	reservationTypes2.setTypeId(5);
    	reservationTypes2.setTypeName("hotel");
    	mockReservationTypesIterable.add(reservationTypes1);
    	mockReservationTypesIterable.add(reservationTypes2);
    	Mockito.when(reservationTypesRepository.findAll()).thenReturn(mockReservationTypesIterable);    	
    	List<ReservationTypesDTO> list = reservationTypesServiceImpl.getReservationTypes();
    	assertEquals(2,list.size());
    }
    @Test
    void fetchAllReservationTypes_Negative() {
    	List<ReservationTypes> mockReservationTypesIterable = new ArrayList<ReservationTypes>();
    	Mockito.when(reservationTypesRepository.findAll()).thenReturn(mockReservationTypesIterable);    	
    	List<ReservationTypesDTO> list = reservationTypesServiceImpl.getReservationTypes();
    	assertEquals(0,list.size());
    }

}
