package com.cognizant.controller;

import com.cognizant.controllers.ReservationTypesController;
import com.cognizant.dto.ReservationTypesDTO;
import com.cognizant.services.ReservationTypesService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class TestReservationTypesController {

    @BeforeEach
    public void setup(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception{

    }

    @Mock
    ReservationTypesService reservationTypesService;

    @InjectMocks
    ReservationTypesController reservationTypesController;

    @Test
    void testGetReservationTypes() {
        ReservationTypesDTO reservationType1 = new ReservationTypesDTO();
        ReservationTypesDTO reservationType2 = new ReservationTypesDTO();
        List<ReservationTypesDTO> reservationTypesList = Arrays.asList(reservationType1, reservationType2);
        when(reservationTypesService.getReservationTypes()).thenReturn(reservationTypesList);
        ResponseEntity<?> response = reservationTypesController.getReservationTypes();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(reservationTypesList, response.getBody());
    }

    @Test
    void testGetReservationTypesEmpty() {

        when(reservationTypesService.getReservationTypes()).thenReturn(Arrays.asList());
        ResponseEntity<?> response = reservationTypesController.getReservationTypes();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Cannot able to fetch the types of reservation types from database", response.getBody());
    }


}
