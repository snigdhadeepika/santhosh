package com.cognizant.controller;

import com.cognizant.controllers.ReservationDocsController;
import com.cognizant.services.ReservationDocsService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class TestReservationDocsController {

    @BeforeEach
    public void setup(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception{

    }

    @Mock
    ReservationDocsService reservationDocsService;

    @InjectMocks
    ReservationDocsController reservationDocsController;

    @Test
    void testHandleDownload() {
        int id = 1;
        File file1 = new File("file1.pdf");
        File file2 = new File("file2.pdf");
        List<File> documentList = Arrays.asList(file1, file2);
        when(reservationDocsService.getDownloadReservation(id)).thenReturn(documentList);
        ResponseEntity<?> response = reservationDocsController.handleDownload(id);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        String serverPort = null;
        List<String> expectedUrls = Arrays.asList(
                "http://localhost:"+serverPort+"/files/" + file1.getName(),
                "http://localhost:"+serverPort+"/files/" + file2.getName()
        );
        assertEquals(expectedUrls, response.getBody());
    }

    @Test
    void testHandleDownloadEmpty() {
        int id = 1;
        when(reservationDocsService.getDownloadReservation(id)).thenReturn(Arrays.asList());
        ResponseEntity<?> response = reservationDocsController.handleDownload(id);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }





}
