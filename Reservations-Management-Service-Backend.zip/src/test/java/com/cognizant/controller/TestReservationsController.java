package com.cognizant.controller;

import com.cognizant.controllers.ReservationsController;
import com.cognizant.dto.AddReservationDTO;
import com.cognizant.dto.ReservationsDTO;
import com.cognizant.exception.DocumentSizeLimitExceededException;
import com.cognizant.exception.EntityBudgetLimitExceededException;
import com.cognizant.services.ReservationsService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TestReservationsController {

    @BeforeEach
    public void setup(){
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void tearDown() throws Exception{

    }

    @Mock
    ReservationsService reservationsService;

    @InjectMocks
    ReservationsController reservationsController;


    @Test
    void testGetReservationById() {
        int id = 1;
        ReservationsDTO reservationData = new ReservationsDTO();
        when(reservationsService.findReservationByReservationId(id)).thenReturn(reservationData);
        ResponseEntity<?> response = reservationsController.getReservationById(id);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(reservationData, response.getBody());
    }

    @Test
    void testGetReservationByIdNotFound() {
        int id = 1;
        when(reservationsService.findReservationByReservationId(id)).thenReturn(null);
        ResponseEntity<?> response = reservationsController.getReservationById(id);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("No reservation found for this reservation id", response.getBody());
    }

    @Test
    void testGetReservationFromTravelRequestId() {
        // Arrange
        int travelRequestId = 1;
        ReservationsDTO reservationData1 = new ReservationsDTO();
        ReservationsDTO reservationData2 = new ReservationsDTO();
        List<ReservationsDTO> reservationsData = Arrays.asList(reservationData1, reservationData2);
        when(reservationsService.findReservationsByTravelRequestId(travelRequestId)).thenReturn(reservationsData);
        ResponseEntity<?> response = reservationsController.getReservationFromTravelRequestId(travelRequestId);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(reservationsData, response.getBody());
    }

    @Test
    void testGetReservationFromTravelRequestIdNotFound() {
        int travelRequestId = 1;
        when(reservationsService.findReservationsByTravelRequestId(travelRequestId)).thenReturn(Arrays.asList());
        ResponseEntity<?> response = reservationsController.getReservationFromTravelRequestId(travelRequestId);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("No reservations found for this travel request id", response.getBody());
    }

    @Test
    void testAddReservation_Success() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO validReservation = new AddReservationDTO();
        when(reservationsService.addReservations(validReservation)).thenReturn("success");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(validReservation);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Successfully Reservation Created", response.getBody());
    }
    @Test
    void testAddReservation_FormatFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO formatFailureReservation = new AddReservationDTO();
        when(reservationsService.addReservations(formatFailureReservation)).thenReturn("formatfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(formatFailureReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Upload only PDF format", response.getBody());
    }
    @Test
    void testAddReservation_DuplicateFlightFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO duplicateFlightReservation = new AddReservationDTO();
        when(reservationsService.addReservations(duplicateFlightReservation)).thenReturn("duplicateflightfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(duplicateFlightReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Flight reservation already done, No duplicate flight reservation allowed", response.getBody());
    }
    @Test
    void testAddReservation_DuplicateTrainFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO duplicateTrainReservation = new AddReservationDTO();
        when(reservationsService.addReservations(duplicateTrainReservation)).thenReturn("duplicatetrainfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(duplicateTrainReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Train reservation already done, No duplicate train reservation allowed", response.getBody());
    }
    @Test
    void testAddReservation_DuplicateBusFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO duplicateBusReservation = new AddReservationDTO();
        when(reservationsService.addReservations(duplicateBusReservation)).thenReturn("duplicatebusfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(duplicateBusReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Bus reservation already done, No duplicate bus reservation allowed", response.getBody());
    }

    @Test
    void testAddReservation_DuplicateHotelFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO duplicateHotelReservation = new AddReservationDTO();
        when(reservationsService.addReservations(duplicateHotelReservation)).thenReturn("duplicatehotelfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(duplicateHotelReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Hotel reservation already done, No duplicate hotel reservation allowed", response.getBody());
    }

    @Test
    void testAddReservation_DuplicateCabFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO duplicateCabReservation = new AddReservationDTO();
        when(reservationsService.addReservations(duplicateCabReservation)).thenReturn("duplicatecabfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(duplicateCabReservation);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Cab reservation already done, No duplicate cab reservation allowed", response.getBody());
    }
    @Test
    void testAddReservation_TravelReservationsDone() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO travelReservationsDone = new AddReservationDTO();
        when(reservationsService.addReservations(travelReservationsDone)).thenReturn("travelreservationsdone");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(travelReservationsDone);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Travel reservation already done", response.getBody());
    }

    @Test
    void testAddReservation_TotalBudgetFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO totalBudgetFailure = new AddReservationDTO();
        when(reservationsService.addReservations(totalBudgetFailure)).thenReturn("totalbudgetfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(totalBudgetFailure);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("It is exceeding your overall budget allocation", response.getBody());
    }

    @Test
    void testAddReservation_TotalReservationsFailure() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO totalReservationsFailure = new AddReservationDTO();
        when(reservationsService.addReservations(totalReservationsFailure)).thenReturn("totalreservationsfailure");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(totalReservationsFailure);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Not more than three reservations allowed", response.getBody());
    }

    @Test
    void testAddReservation_DefaultCase() throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO defaultCase = new AddReservationDTO();
        when(reservationsService.addReservations(defaultCase)).thenReturn("anyOtherCase");
        ResponseEntity<String> response = (ResponseEntity<String>) reservationsController.addReservation(defaultCase);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Save failed", response.getBody());
    }
    @Test
     void testHandleValidationExceptions() throws Exception {
        // Arrange
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        BindingResult bindingResult = mock(BindingResult.class);
        ObjectError objectError = new ObjectError("objectName", "defaultMessage");
        when(ex.getBindingResult()).thenReturn(bindingResult);
        when(bindingResult.getAllErrors()).thenReturn(Collections.singletonList(objectError));
        ResponseEntity<?> response = reservationsController.handleValidationExceptions(ex);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody() instanceof List);
        List<String> errorMessages = (List<String>) response.getBody();
        assertEquals(1, errorMessages.size());
        assertEquals("defaultMessage", errorMessages.get(0));
    }
    @Test
    void testAddReservationException() throws InstantiationException, IllegalAccessException, EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {
        AddReservationDTO addReservationDTO = new AddReservationDTO();
        when(reservationsService.addReservations(AddReservationDTO.class.newInstance())).thenThrow(new RuntimeException("Test exception"));
        ResponseEntity<?> response = reservationsController.addReservation(addReservationDTO);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }






}
