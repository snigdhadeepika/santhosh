package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.entities.ReservationDocs;
import com.cognizant.ReservationsModuleApplication;


@DataJpaTest
@ContextConfiguration(classes = ReservationsModuleApplication.class)
class TestReservationDocsRepository {
	
	@Autowired
	private ReservationDocsRepository reservationDocsRepository; 
	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void testFindAllPositive() {
		ReservationDocs reservationDoc = new ReservationDocs();
		reservationDoc.setDocumentURL("www.yourdocument.com");
		entityManager.persist(reservationDoc);
		Iterable<ReservationDocs> iterable = reservationDocsRepository.findAll();
		assertTrue(iterable.iterator().hasNext());
	}
	
		@Test
		public void testFindAllNegative() {
			Iterable<ReservationDocs> iterable = reservationDocsRepository.findAll();
			assertTrue(!iterable.iterator().hasNext());
	
		}
		@Test
		public void testFindByIdPositive() {
			ReservationDocs reservationDoc = new ReservationDocs();
			reservationDoc.setDocumentURL("www.yourdocument.com");
			int id=entityManager.persist(reservationDoc).getId();
			Optional<ReservationDocs> reservations = reservationDocsRepository.findById(id);
			assertTrue(reservations.isPresent());
		}
	  
		@Test
		public void testFindByIdNegative() {
			Optional<ReservationDocs> reservationDoc = reservationDocsRepository.findById(1);
			assertTrue(!reservationDoc.isPresent());
		}

		@Test
		public void testSavePositive() {
			ReservationDocs reservationDoc = new ReservationDocs();
			reservationDoc.setDocumentURL("www.yourdocument.com");
			int id=entityManager.persist(reservationDoc).getId();
			Optional<ReservationDocs> reservations = reservationDocsRepository.findById(id);
			assertTrue(reservations.isPresent());
		}

		@Test
		public void testDeletePositive() {
			ReservationDocs reservationDoc = new ReservationDocs();
			reservationDoc.setDocumentURL("www.yourdocument.com");
			entityManager.persist(reservationDoc);
			reservationDocsRepository.delete(reservationDoc);
			Optional<ReservationDocs> reservations = reservationDocsRepository.findById(1);
			assertTrue(!reservations.isPresent());
		}
	

}
