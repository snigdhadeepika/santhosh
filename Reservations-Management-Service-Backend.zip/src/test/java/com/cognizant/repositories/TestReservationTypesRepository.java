package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.entities.ReservationTypes;
import com.cognizant.ReservationsModuleApplication;


@DataJpaTest
@ContextConfiguration(classes = ReservationsModuleApplication.class)
class TestReservationTypesRepository {


	@Autowired
	private ReservationTypesRepository reservationTypesRepository;
	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void testFindAllPositive() {
		ReservationTypes reservationType = new ReservationTypes();
		reservationType.setTypeId(8);
		reservationType.setTypeName("ship");
		entityManager.persist(reservationType);
		Iterable<ReservationTypes> it = reservationTypesRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	
		@Test
		public void testFindAllNegative() {
			Iterable<ReservationTypes> iterable = reservationTypesRepository.findAll();
			assertTrue(iterable.iterator().hasNext());
		}
		@Test
		public void testFindByIdPositive() {
			ReservationTypes reservationType = new ReservationTypes();
			reservationType.setTypeId(1);
			reservationType.setTypeName("flight");
			entityManager.persist(reservationType);
			Optional<ReservationTypes> reservations = reservationTypesRepository.findById(1);
			assertTrue(reservations.isPresent());
		}
	  
		@Test
		public void testFindByIdNegative() {
			Optional<ReservationTypes> reservationType = reservationTypesRepository.findById(9);
			assertTrue(!reservationType.isPresent());
		}

		@Test
		public void testSavePositive() {
			ReservationTypes reservationType = new ReservationTypes();
			reservationType.setTypeId(1);
			reservationType.setTypeName("flight");
			entityManager.persist(reservationType);
			Optional<ReservationTypes> reservations = reservationTypesRepository.findById(1);
			assertTrue(reservations.isPresent());
		}

		@Test
		public void testDeletePositive() {
			ReservationTypes reservationType = new ReservationTypes();
			reservationType.setTypeId(1);
			reservationType.setTypeName("flight");
			entityManager.persist(reservationType);
			reservationTypesRepository.delete(reservationType);
			Optional<ReservationTypes> reservations = reservationTypesRepository.findById(1);
			assertTrue(!reservations.isPresent());
		}


}
