package com.cognizant.repositories;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.entities.Reservations;
import com.cognizant.ReservationsModuleApplication;


@DataJpaTest
@ContextConfiguration(classes = ReservationsModuleApplication.class)
class TestReservationsRepository {

	@Autowired
	private ReservationsRepository reservationsRepository;
	@Autowired
	private TestEntityManager entityManager;

	@Test
	public void testFindAllPositive() {
		Reservations reservation = new Reservations();
		reservation.setReservationDoneByEmployeeId(112012);
		reservation.setTravelRequestId(23412);
		reservation.setCreatedOn(LocalDate.now());
		reservation.setReservationDoneWithEntity("2000");
		reservation.setReservationDate(LocalDate.parse("2022-02-10"));
		reservation.setAmount(25000);
		reservation.setRemarks("Hotel Booking");
		reservation.setConfirmationID("S200");
		entityManager.persist(reservation);
		Iterable<Reservations> iterable = reservationsRepository.findAll();
		assertTrue(iterable.iterator().hasNext());
	}
	
		@Test
		public void testFindAllNegative() {
			Iterable<Reservations> iterable = reservationsRepository.findAll();
			assertTrue(!iterable.iterator().hasNext());
	
		}
		@Test
		public void testFindByIdPositive() {
			Reservations reservation = new Reservations();
			reservation.setReservationDoneByEmployeeId(112012);
			reservation.setTravelRequestId(23412);
			reservation.setCreatedOn(LocalDate.now());
			reservation.setReservationDoneWithEntity("2000");
			reservation.setReservationDate(LocalDate.parse("2022-02-10"));
			reservation.setAmount(25000);
			reservation.setRemarks("Hotel Booking");
			reservation.setConfirmationID("S200");
			entityManager.persist(reservation);
			Optional<Reservations> reservations = reservationsRepository.findById(reservation.getId());
			assertTrue(reservations.isPresent());
		}
	  
		@Test
		public void testFindByIdNegative() {
			Optional<Reservations> reservation = reservationsRepository.findById(1);
			assertTrue(!reservation.isPresent());
		}

		@Test
		public void testSavePositive() {
			Reservations reservation = new Reservations();
			reservation.setReservationDoneByEmployeeId(112012);
			reservation.setTravelRequestId(23412);
			reservation.setCreatedOn(LocalDate.now());
			reservation.setReservationDoneWithEntity("2000");
			reservation.setReservationDate(LocalDate.parse("2022-02-10"));
			reservation.setAmount(25000);
			reservation.setRemarks("Hotel Booking");
			reservation.setConfirmationID("S200");
			int id=reservationsRepository.save(reservation).getId();
			Optional<Reservations> reservations = reservationsRepository.findById(id);
			assertTrue(reservations.isPresent());
		}

		@Test
		public void testDeletePositive() {
			Reservations reservation = new Reservations();
			reservation.setReservationDoneByEmployeeId(112012);
			reservation.setTravelRequestId(23412);
			reservation.setCreatedOn(LocalDate.now());
			reservation.setReservationDoneWithEntity("2000");
			reservation.setReservationDate(LocalDate.parse("2022-02-10"));
			reservation.setAmount(25000);
			reservation.setRemarks("Hotel Booking");
			reservation.setConfirmationID("S200");
			entityManager.persist(reservation);
			reservationsRepository.delete(reservation);
			Optional<Reservations> reservations = reservationsRepository.findById(1);
			assertTrue(!reservations.isPresent());
		}
}
