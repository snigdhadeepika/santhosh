package com.cognizant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ReservationsModuleApplication.class)
class ReservationsModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
