package com.cognizant.utilities;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.dto.AddReservationDTO;
import com.cognizant.entities.Reservations;
import com.cognizant.repositories.ReservationsRepository;

@Component
public class ValidateReservation {

@Autowired
public ReservationsRepository reservationRepository;

    final String BUS_RESERVATION_DONE="bus reservation done";
    final String FLIGHT_RESERVATION_DONE="flight reservation done";
    final String HOTEL_RESERVATION_DONE="hotel reservation done";
    final String CAB_RESERVATION_DONE="cab reservation done";
    final String TRAIN_RESERVATION_DONE="train reservation done";
    final String TRAVEL_RESERVATION_DONE="travelreservationsdone";


    public boolean validateRecord(List<String> urls) {
        try {
            for(String url:urls) {
                URL pdfUrl=new URL(url);
                HttpURLConnection connection=(HttpURLConnection)pdfUrl.openConnection();
                connection.setRequestMethod("HEAD");

                long fileSizeInBytes=connection.getContentLengthLong();
                long fileSizeInKB=fileSizeInBytes/1024;
                if(fileSizeInKB>1024) {
                    return false;
                }
            }
        }
        catch(IOException e) {
            return false;
        }
        return true;
    }
    public boolean containsPdf(List<String> urls) {
        for(String url: urls) {
            if(!url.contains(".pdf")) {
                return false;
            }
        }
        return true;
    }

    public String totalCheckReservations(int travelRequestId, String reservationDoneWithEntity) {
    List<Reservations> reservations = reservationRepository.findByTravelRequestId(travelRequestId);
    int totalReservations = 0;
    boolean flightReservationExists = false;
    boolean busReservationExists = false;
    boolean trainReservationExists = false;
    boolean hotelReservationExists = false;
    boolean cabReservationExists = false;

    for (Reservations reservation : reservations) {
        totalReservations++;

        switch (reservation.getReservationDoneWithEntity()) {
            case "flight":
                flightReservationExists = true;
                break;
            case "bus":
                busReservationExists = true;
                break;
            case "train":
                trainReservationExists = true;
                break;
            case "hotel":
                hotelReservationExists = true;
                break;
            case "cab":
                cabReservationExists = true;
                break;
        }
    }
        if (totalReservations >= 3) {
            return "more than 3 reservations";
        }

        if (flightReservationExists && ("flight".equals(reservationDoneWithEntity))){
            return FLIGHT_RESERVATION_DONE;
        }
        else if (busReservationExists && ("bus".equals(reservationDoneWithEntity))){
            return BUS_RESERVATION_DONE;
        }
        else if (trainReservationExists && ("train".equals(reservationDoneWithEntity))){
            return TRAIN_RESERVATION_DONE;
        }
        else if (cabReservationExists && ("cab".equals(reservationDoneWithEntity))){
            return CAB_RESERVATION_DONE;
        }
        else if (hotelReservationExists && ("hotel".equals(reservationDoneWithEntity))){
            return HOTEL_RESERVATION_DONE;
        }
        else if (flightReservationExists && ("bus".equals(reservationDoneWithEntity) || "train".equals(reservationDoneWithEntity))){
            return TRAVEL_RESERVATION_DONE;
        }
        else if (busReservationExists && ("flight".equals(reservationDoneWithEntity) || "train".equals(reservationDoneWithEntity))){
            return TRAVEL_RESERVATION_DONE;
        }
        else if (trainReservationExists && ("flight".equals(reservationDoneWithEntity) || "bus".equals(reservationDoneWithEntity))){
            return TRAVEL_RESERVATION_DONE;
        }

    
    return "success";
}

}

