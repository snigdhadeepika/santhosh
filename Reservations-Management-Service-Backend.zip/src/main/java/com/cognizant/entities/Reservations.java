package com.cognizant.entities;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity 
@Table(name="Reservations")
public class Reservations {

   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name="Id")
   private int id;
   @Column(name = "Reservation_Done_By_Employee_Id")
   private int reservationDoneByEmployeeId;
   @Column(name = "Travel_Request_Id")
   private int travelRequestId;
   @ManyToOne
   @JoinColumn(name="Reservation_Type_Id",referencedColumnName="Type_Id")
   private ReservationTypes reservationTypes;
   

   @Column(name = "Created_On")
   private LocalDate createdOn;
   @Column(name = "Reservation_Done_With_Entity")
   private String reservationDoneWithEntity;
   @Column(name = "Reservation_Date")
   private LocalDate reservationDate;
   @Column(name = "Amount")
   private int amount;
   @Column(name = "Confirmation_Id")
   private String confirmationID;
   @Column(name = "Remarks")
   private String remarks;
   
   @OneToMany(cascade=CascadeType.ALL,mappedBy="reservations")
   private List<ReservationDocs> reservationDocs;

}