 package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication(scanBasePackages = "com.cognizant.*")
@EnableDiscoveryClient(autoRegister = true)
public class ReservationsModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservationsModuleApplication.class, args);
	}

}
