package com.cognizant.mapper;

import org.springframework.stereotype.Component;

import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.Reservations;

@Component
public class ReservationsMapper {
	
	public ReservationsDTO toReservationDto(Reservations reservation) {
		ReservationsDTO reservationDTO=new ReservationsDTO();
		reservationDTO.setId(reservation.getId());
		reservationDTO.setReservationDoneByEmployeeId(reservation.getReservationDoneByEmployeeId());
		reservationDTO.setTravelRequestId(reservation.getTravelRequestId());
		reservationDTO.setReservaionTypeId(reservation.getReservationTypes().getTypeId());
		reservationDTO.setCreatedOn(reservation.getCreatedOn());
		reservationDTO.setReservationDoneWithEntity(reservation.getReservationDoneWithEntity());
		reservationDTO.setReservationDate(reservation.getReservationDate());
		reservationDTO.setAmount(reservation.getAmount());
		reservationDTO.setConfirmationID(reservation.getConfirmationID());
		reservationDTO.setRemarks(reservation.getRemarks());
		return reservationDTO;
	}

}
