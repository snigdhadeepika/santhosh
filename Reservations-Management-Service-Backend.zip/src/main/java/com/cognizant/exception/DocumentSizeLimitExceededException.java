package com.cognizant.exception;

public class DocumentSizeLimitExceededException extends Exception {

    public DocumentSizeLimitExceededException(String message) {
        super(message);
    }
}