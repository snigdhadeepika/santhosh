package com.cognizant.exception;

public class EntityBudgetLimitExceededException extends Exception{

    public EntityBudgetLimitExceededException(String message) {
        super(message);
    }
}
