package com.cognizant.authentication.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Data
@Entity
@Table(name="Users")
public class Users {
    @Id
    @Column(name="Username")
    private String username;
    @Column(name="Password")
    private String password;
    @Column(name="Role")
    private String role;
    @Column(name="Is_Account_Locked")
    private boolean isAccountLocked;

}
