package com.cognizant.authentication.service;

import com.cognizant.authentication.dto.UserDTO;
import com.cognizant.authentication.entity.Users;

import java.util.List;

public interface UserService {
    public List<Users> listOfUsers();
    public UserDTO authenticateUser(String username, String password);

}
