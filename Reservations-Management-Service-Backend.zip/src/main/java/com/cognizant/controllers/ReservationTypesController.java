package com.cognizant.controllers;

import com.cognizant.dto.ReservationTypesDTO;
import com.cognizant.services.ReservationTypesService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Slf4j
@RestController
@RequestMapping("api/reservations")
@CrossOrigin("http://localhost:4200/")
public class ReservationTypesController {

    @Autowired
    private ReservationTypesService reservationTypesService;


    @Operation(description = "Fetch all reservation types")
    @GetMapping("types")
    public ResponseEntity<?> getReservationTypes() {
        List<ReservationTypesDTO> reservationTypesList=reservationTypesService.getReservationTypes();
        if(reservationTypesList.isEmpty()) {
            log.info("Cannot able to fetch the types of reservation types");
            return new ResponseEntity<>("Cannot able to fetch the types of reservation types from database", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        else {
            log.info("Successfully able to fetch the reservation types");
            return new ResponseEntity<>(reservationTypesList,HttpStatus.OK);
        }
    }


}
