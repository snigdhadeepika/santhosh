package com.cognizant.controllers;

import com.cognizant.repositories.ReservationDocsRepository;
import com.cognizant.services.ReservationDocsService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@RestController
@RequestMapping("api/reservations")
@CrossOrigin("http://localhost:4200/")
public class ReservationDocsController {

    @Value("${server.port}")
    private String serverPort;

    @Autowired
    ReservationDocsService reservationDocsService;

    @Operation(description = "Get all reservation details and documents")
    @GetMapping("{reservationId}/download")
    public ResponseEntity<?> handleDownload(@PathVariable("reservationId") int id){
        List<File> documentList = reservationDocsService.getDownloadReservation(id);
        if(!documentList.isEmpty()) {
            List<String> fileUrls = documentList.stream()
                    .map(file -> "http://localhost:"+serverPort+"/files/" + file.getName())
                    .collect(Collectors.toList());
            log.info("The file was able to download successfully");
            return new ResponseEntity<>(fileUrls, HttpStatus.OK);
        } else {
            log.info("Failed to download the files");
            return new ResponseEntity<>("Cannot able to download the files",HttpStatus.NOT_FOUND);
        }
    }
}
