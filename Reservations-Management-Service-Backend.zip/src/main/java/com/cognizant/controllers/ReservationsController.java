package com.cognizant.controllers;

import java.util.List;
import java.util.stream.Collectors;

import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;


import com.cognizant.dto.AddReservationDTO;
import com.cognizant.dto.ReservationsDTO;
import com.cognizant.services.ReservationsService;

import jakarta.validation.Valid;
@Slf4j
@RestController
@RequestMapping("api/reservations")
@CrossOrigin("http://localhost:4200/")
public class ReservationsController {

	
	@Autowired
	private ReservationsService reservationsService;

	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex) {
	    BindingResult bindingResult = ex.getBindingResult();
	    List<String> errorMessages = bindingResult.getAllErrors().stream()
	            .map(DefaultMessageSourceResolvable::getDefaultMessage)
	            .collect(Collectors.toList());
	    return new ResponseEntity<>(errorMessages, HttpStatus.BAD_REQUEST);
	}
	
	@Operation(description = "Add a new reservation details")
	@PostMapping("add") 
	public ResponseEntity<?> addReservation(@Valid @RequestBody AddReservationDTO addReservationDTO)
	{ 
		try 
		{ 
			String result = reservationsService.addReservations(addReservationDTO); 
			switch (result) 
			{
				case "success":
					log.info("Successfully Reservation Created");
					return new ResponseEntity<>("Successfully Reservation Created",HttpStatus.OK);
				case "formatfailure":
					log.info("Upload only PDF format");
					return new ResponseEntity<>("Upload only PDF format",HttpStatus.BAD_REQUEST);
				case "duplicateflightfailure":
					log.info("Flight reservation already done, No duplicate flight reservation allowed");
					return new ResponseEntity<>("Flight reservation already done, No duplicate flight reservation allowed", HttpStatus.BAD_REQUEST);
				case "duplicatetrainfailure":
					log.info("Train reservation already done, No duplicate train reservation allowed");
					return new ResponseEntity<>("Train reservation already done, No duplicate train reservation allowed", HttpStatus.BAD_REQUEST);
				case "duplicatebusfailure":
					log.info("Bus reservation already done, No duplicate bus reservation allowed");
					return new ResponseEntity<>("Bus reservation already done, No duplicate bus reservation allowed", HttpStatus.BAD_REQUEST);
				case "duplicatehotelfailure":
					log.info("Hotel reservation already done, No duplicate hotel reservation allowed");
					return new ResponseEntity<>("Hotel reservation already done, No duplicate hotel reservation allowed", HttpStatus.BAD_REQUEST);
				case "duplicatecabfailure":
					log.info("Cab reservation already done, No duplicate cab reservation allowed");
					return new ResponseEntity<>("Cab reservation already done, No duplicate cab reservation allowed", HttpStatus.BAD_REQUEST);
				case "travelreservationsdone":
					log.info("Travel reservation already done");
					return new ResponseEntity<>("Travel reservation already done",HttpStatus.BAD_REQUEST);
				case "totalbudgetfailure":
					log.info("It is exceeding your overall budget allocation");
					return new ResponseEntity<>("It is exceeding your overall budget allocation",HttpStatus.BAD_REQUEST);
				case "totalreservationsfailure":
					log.info("Not more than three reservations allowed");
					return new ResponseEntity<>("Not more than three reservations allowed",HttpStatus.BAD_REQUEST);
				default:
					log.info("Save failed");
					return new ResponseEntity<>("Save failed", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		catch (Exception e) 
		{
			log.info("Having an exception and got the message");
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); 
		} 
	}

	@Operation(description = "Fetch all reservations for an travel request id")
	@GetMapping("track/{travelRequestId}")
	public ResponseEntity<?> getReservationFromTravelRequestId(@PathVariable("travelRequestId")int travelRequestId){
		List<ReservationsDTO> reservationsData=reservationsService.findReservationsByTravelRequestId(travelRequestId);
		if(reservationsData.isEmpty()) {
			log.info("No reservations found for this travel request id");
			return new ResponseEntity<>("No reservations found for this travel request id",HttpStatus.NOT_FOUND);
		}
		else {
			log.info("Successfully fetched all reservations for your travel request id");
			return new ResponseEntity<>(reservationsData,HttpStatus.OK);
		}
	}
	@Operation(description = "Fetch reservation for an reservation id")
	@GetMapping("{reservationId}")
	public ResponseEntity<?> getReservationById(@PathVariable("reservationId") int id) {
		ReservationsDTO reservationData= reservationsService.findReservationByReservationId(id);
		if(reservationData==null) {
			log.info("No reservation found for this reservation id");
			return new ResponseEntity<>("No reservation found for this reservation id",HttpStatus.NOT_FOUND);
		}
		else {
			log.info("Successfully fetched reservation for this reservation id");
			return new ResponseEntity<>(reservationData,HttpStatus.OK);
		}
	}

}
	
	


