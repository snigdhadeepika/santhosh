package com.cognizant.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.ReservationTypesDTO;
import com.cognizant.entities.ReservationTypes;
import com.cognizant.repositories.ReservationTypesRepository;


@Service
public class ReservationTypesServiceImpl implements ReservationTypesService{
	
	
	@Autowired
	public ReservationTypesRepository reservationTypesRepository;

	@Override
	public List<ReservationTypesDTO> getReservationTypes() {
		Iterable<ReservationTypes> reservationTypes=reservationTypesRepository.findAll();
		List<ReservationTypesDTO> reservationTypesDTO=new ArrayList<>();
		for(ReservationTypes rt:reservationTypes) {
			ReservationTypesDTO rtd=new ReservationTypesDTO();
			rtd.setTypeId(rt.getTypeId());
			rtd.setTypeName(rt.getTypeName());
			reservationTypesDTO.add(rtd);
		}
		return reservationTypesDTO;
	}
	
	

}
