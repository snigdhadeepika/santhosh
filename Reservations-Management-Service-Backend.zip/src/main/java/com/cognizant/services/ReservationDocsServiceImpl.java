package com.cognizant.services;


import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.ReservationDocs;
import com.cognizant.entities.Reservations;
import com.cognizant.repositories.ReservationDocsRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.net.ssl.HttpsURLConnection;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReservationDocsServiceImpl implements ReservationDocsService{

    @Autowired
    ReservationDocsRepository reservationDocsRepository;

    @Autowired
    ReservationsService reservationsService;

    @Override
    public List<File> getDownloadReservation(int id) {
        Iterable<ReservationDocs> allReservationDocs = reservationDocsRepository.findAll();

        List<File> downloadedFiles = new ArrayList<>();
        int count=0;
        File directory=null;
        for (ReservationDocs reservationDoc : allReservationDocs) {
            Reservations reservation = reservationDoc.getReservations();
            if (reservation != null && reservation.getId() == id) {
                String documentURL = reservationDoc.getDocumentURL();
                String entityType = reservation.getReservationDoneWithEntity();
                byte[] documentContent = getDocumentContent(documentURL);
                if (documentContent != null) {
                    try {
                        String filename = count + "_"+reservation.getReservationDoneByEmployeeId()+"_"+ entityType + ".pdf";
                        count=count+1;
                        directory = new File("src/main/resources/" + "documentPDFs");
                        if (!directory.exists()) {
                            directory.mkdirs();
                        }
                        File file = new File(directory, filename);

                        try (FileOutputStream fos = new FileOutputStream(file)) {
                            fos.write(documentContent);
                        }
                        downloadedFiles.add(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        ReservationsDTO reservationsDTO=reservationsService.findReservationByReservationId(id);
        try {
            String filename = reservationsDTO.getReservationDoneByEmployeeId() + "_details.pdf";
            File file = new File(directory, filename);
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(file));
            document.open();
            document.add(new Paragraph("Reservation ID: " + reservationsDTO.getId()));
            document.add(new Paragraph("Reservation Done By Employee ID: "+reservationsDTO.getReservationDoneByEmployeeId()));
            document.add(new Paragraph("Travel Request ID: "+reservationsDTO.getTravelRequestId()));
            document.add(new Paragraph("Created On: "+reservationsDTO.getCreatedOn()));
            document.add(new Paragraph("Reservation Done With Entity: "+reservationsDTO.getReservationDoneWithEntity()));
            document.add(new Paragraph("Reservation Date: "+reservationsDTO.getReservationDate()));
            document.add(new Paragraph("Amount: "+reservationsDTO.getAmount()));
            document.add(new Paragraph("Confirmation ID: "+reservationsDTO.getConfirmationID()));
            document.add(new Paragraph("Remarks: "+reservationsDTO.getRemarks()));
            document.close();
            downloadedFiles.add(file);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return downloadedFiles;
    }

    public byte[] getDocumentContent(String documentURL) {
        try {
            if (documentURL.startsWith("http:") || documentURL.startsWith("https:")) {

                URL url = new URL(documentURL);
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                try (InputStream in = conn.getInputStream()) {
                    return in.readAllBytes();
                }
            } else {
                Path path = Paths.get(documentURL);
                return Files.readAllBytes(path);
            }
        } catch (IOException e) {
            return null;
        }
    }
}



