package com.cognizant.services;

import java.io.File;
import java.util.List;

import com.cognizant.dto.AddReservationDTO;
import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.Reservations;
import com.cognizant.exception.DocumentSizeLimitExceededException;
import com.cognizant.exception.EntityBudgetLimitExceededException;

public interface ReservationsService {
	
	public String addReservations(AddReservationDTO reservation) throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException;
	public List<ReservationsDTO> findReservationsByTravelRequestId(int travelRequestId);
	public ReservationsDTO findReservationByReservationId(int reservationId);

	
	

}
