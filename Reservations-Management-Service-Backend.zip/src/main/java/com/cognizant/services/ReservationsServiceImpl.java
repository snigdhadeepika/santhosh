package com.cognizant.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cognizant.exception.DocumentSizeLimitExceededException;
import com.cognizant.exception.EntityBudgetLimitExceededException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.AddReservationDTO;
import com.cognizant.dto.Budget;
import com.cognizant.dto.ReservationsDTO;
import com.cognizant.entities.ReservationDocs;
import com.cognizant.entities.ReservationTypes;
import com.cognizant.entities.Reservations;
import com.cognizant.repositories.ReservationDocsRepository;
import com.cognizant.repositories.ReservationTypesRepository;
import com.cognizant.repositories.ReservationsRepository;
import com.cognizant.mapper.ReservationsMapper;
import com.cognizant.utilities.ValidateReservation;



@Service
public class ReservationsServiceImpl implements ReservationsService {

	@Autowired
	public ReservationsRepository reservationRepository;

	@Autowired
	public ReservationDocsRepository reservationDocsRepository;

	@Autowired
	public ReservationTypesRepository reservationTypesRepository;

	@Autowired
	public ReservationsMapper reservationMapper;


	@Autowired
	public ValidateReservation validate;

	final String DUPLICATE_FLIGHT_FAILURE="duplicateflightfailure";
	final String DUPLICATE_TRAIN_FAILURE="duplicatetrainfailure";
	final String DUPLICATE_HOTEL_FAILURE="duplicatehotelfailure";
	final String DUPLICATE_CAB_FAILURE="duplicatecabfailure";
	final String DUPLICATE_BUS_FAILURE="duplicatebusfailure";
	final String TRAVEL_RESERVATIONS_DONE="travelreservationsdone";
	final String TOTAL_RESERVATIONS_FAILURE="totalreservationsfailure";

	final String FORMAT_FAILURE="formatfailure";

	final String TOTAL_BUDGET_FAILUE="totalbudgetfailure";

	final String SUCCESS="success";
	final String FAILURE="failure";

	@Override
	public String addReservations(AddReservationDTO addReservationDTO) throws EntityBudgetLimitExceededException, DocumentSizeLimitExceededException {


		if(!validate.containsPdf(addReservationDTO.getDocumentURLS())){
			return FORMAT_FAILURE;
		}
		if(!validate.validateRecord(addReservationDTO.getDocumentURLS())) {
			throw new DocumentSizeLimitExceededException("Document size limit exceeded");
		}
		String resultCondition=validate.totalCheckReservations(addReservationDTO.getTravelRequestId(),addReservationDTO.getReservationDoneWithEntity());
		if("flight reservation done".equals(resultCondition)){
			return DUPLICATE_FLIGHT_FAILURE;
		}
		else if("train reservation done".equals(resultCondition)){
			return DUPLICATE_TRAIN_FAILURE;
		}
		else if("bus reservation done".equals(resultCondition)){
			return DUPLICATE_BUS_FAILURE;
		}
		else if("hotel reservation done".equals(resultCondition)) {
			return DUPLICATE_HOTEL_FAILURE;
		}
		else if("cab reservation done".equals(resultCondition)){
			return DUPLICATE_CAB_FAILURE;
		}
		else if("travelreservationsdone".equals(resultCondition)){
			return TRAVEL_RESERVATIONS_DONE;
		}
		else if("more than 3 reservations".equals(resultCondition)){
			return TOTAL_RESERVATIONS_FAILURE;
		}
		if (("train".equals(addReservationDTO.getReservationDoneWithEntity()) || "bus".equals(addReservationDTO.getReservationDoneWithEntity()))
				&& !addReservationDTO.getReservationDate().equals(addReservationDTO.getFromDate().minusDays(1)))
		{
			throw new IllegalArgumentException("Reservation date for a train/bus reservation must be 1 day before from date");
		}
		if ("hotel".equals(addReservationDTO.getReservationDoneWithEntity()) && !addReservationDTO.getReservationDate().equals(addReservationDTO.getFromDate()))
		{
			throw new IllegalArgumentException("Reservation date for a hotel must be the same as the from date");
		}


		int currentamount=addReservationDTO.getAmount();
		int budget=(int) Budget.valueOf(addReservationDTO.getReservationDoneWithEntity().toUpperCase()).getVal();
		if(currentamount>0.7*budget) {
			throw new EntityBudgetLimitExceededException(addReservationDTO.getReservationDoneWithEntity()+" amount must be below "+(int)(0.7*budget)+" or 70 percent of the budget");
		}

		int reservationSize=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId()).size();
		if(reservationSize==2)
		{
			int firstAmount=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId()).get(0).getAmount();
			int secondAmount=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId()).get(1).getAmount();
			String firstEntityReservation=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId()).get(0).getReservationDoneWithEntity();
			String secondEntityReservation=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId()).get(1).getReservationDoneWithEntity();
			int firstBudget = (int) Budget.valueOf(firstEntityReservation.toUpperCase()).getVal();
			int secondBudget = (int) Budget.valueOf(secondEntityReservation.toUpperCase()).getVal();
			if ((firstAmount + secondAmount + currentamount) > 0.7 * (firstBudget + secondBudget + budget)) {
				List<Reservations> currentReservations=reservationRepository.findByTravelRequestId(addReservationDTO.getTravelRequestId());
				Iterator<Reservations> iterator = currentReservations.iterator();
				while (iterator.hasNext()) {
					Reservations reservation = iterator.next();
					reservationRepository.delete(reservation);
				}
				return TOTAL_BUDGET_FAILUE;
			}
		}



		Reservations reservation=new Reservations();
		reservation.setReservationDoneByEmployeeId(addReservationDTO.getReservationDoneByEmployeeId());
		Iterable<ReservationTypes> reservationTypesAll = reservationTypesRepository.findAll();
		int id = 0;
		for(ReservationTypes reservationtypeCheck : reservationTypesAll) {
			if(reservationtypeCheck.getTypeName().equals(addReservationDTO.getReservationDoneWithEntity())){
				id = reservationtypeCheck.getTypeId();
			}
		}
		ReservationTypes rt=new ReservationTypes();
		rt.setTypeId(id);
		reservation.setReservationTypes(rt);
		reservation.setTravelRequestId(addReservationDTO.getTravelRequestId());
		reservation.setReservationDoneWithEntity(addReservationDTO.getReservationDoneWithEntity());
		reservation.setCreatedOn(LocalDate.now());
		reservation.setReservationDate(addReservationDTO.getReservationDate());
		reservation.setAmount(addReservationDTO.getAmount());
		reservation.setConfirmationID(addReservationDTO.getConfirmationID());
		reservation.setRemarks(addReservationDTO.getRemarks());
		List<String> documentURLs=addReservationDTO.getDocumentURLS();
		List<ReservationDocs> reservationDocsList=new CopyOnWriteArrayList<>();
		for(String documentURL:documentURLs) {
			ReservationDocs reservationDocuments=new ReservationDocs();
			reservationDocuments.setReservations(reservation);
			reservationDocuments.setDocumentURL(documentURL);
			reservationDocsList.add(reservationDocuments);
		}
		reservation.setReservationDocs(reservationDocsList);
		Reservations reservationSave=reservationRepository.save(reservation);
		if(reservationSave!=null) {
			try {
				for(ReservationDocs reservationdoc:reservationDocsList) {
					reservationDocsRepository.save(reservationdoc);
				}
				return SUCCESS;
			} catch (Exception e) {
				for(ReservationDocs rollbackDoc:reservationDocsList) {
					reservationDocsRepository.delete(rollbackDoc);
				}
				reservationRepository.delete(reservationSave);
				return FAILURE;
			}
		}
		return FAILURE;
	}






	@Override
	public List<ReservationsDTO> findReservationsByTravelRequestId(int travelRequestId) {
		List<Reservations> reservations=reservationRepository.findByTravelRequestId(travelRequestId);
		Iterator<Reservations> iterator=reservations.iterator();
		List<ReservationsDTO> reservationDTOList = new ArrayList<>();
		ReservationsDTO reservationDTO = new ReservationsDTO();
		while(iterator.hasNext()) {
			Reservations reservation = iterator.next();
			reservationDTO=reservationMapper.toReservationDto(reservation);
			reservationDTOList.add(reservationDTO);
		}
		return reservationDTOList;
	}



	@Override
	public ReservationsDTO findReservationByReservationId(int id) {
		Optional<Reservations> reservationIndividual=reservationRepository.findById(id);
		ReservationsDTO reservationDTO=new ReservationsDTO();
		if(reservationIndividual.isPresent()) {
			Reservations reservation=reservationIndividual.get();
			reservationDTO=reservationMapper.toReservationDto(reservation);
			return reservationDTO;
		}
		return null;

	}

	
}








