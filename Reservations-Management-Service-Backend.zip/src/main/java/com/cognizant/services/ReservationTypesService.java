package com.cognizant.services;

import java.util.List;

import com.cognizant.dto.ReservationTypesDTO;

public interface ReservationTypesService {
	
	public List<ReservationTypesDTO> getReservationTypes();

}
