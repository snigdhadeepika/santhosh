package com.cognizant.services;

import java.io.File;
import java.util.List;

public interface ReservationDocsService {

    public List<File> getDownloadReservation(int reservationId);

}
