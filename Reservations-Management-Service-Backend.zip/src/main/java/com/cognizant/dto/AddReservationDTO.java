package com.cognizant.dto;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddReservationDTO {

	@NotNull(message="The employee id should not be null")
	private Integer reservationDoneByEmployeeId;
	@NotNull(message="The travel request id should not be null")
	private Integer travelRequestId;

	@NotBlank(message="The reservation done with entity should not be blank")
	private String reservationDoneWithEntity;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@FutureOrPresent
	private LocalDate reservationDate;
	@NotNull(message = "Amount should not be null")
	@PositiveOrZero(message = "Amount must be positive")
	private Integer amount;
	@NotBlank(message="The confirmation id should not be blank")
	private String confirmationID;
	@NotBlank(message="The remarks should not be blank")
	private String remarks;
	@NotEmpty(message="The documentURLS should not be null or empty")
	private List<String> documentURLS;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@FutureOrPresent
	private LocalDate fromDate;


}
