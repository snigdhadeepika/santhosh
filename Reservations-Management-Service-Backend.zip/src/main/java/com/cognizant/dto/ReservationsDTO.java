package com.cognizant.dto;

import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
public class ReservationsDTO {


	private int id;
	private int reservationDoneByEmployeeId;
	private int travelRequestId;
	private int reservaionTypeId;
	private LocalDate createdOn;
	private String reservationDoneWithEntity;
	private LocalDate reservationDate;
	private int amount;
	private String confirmationID;
	private String remarks;
	
}
	

	
