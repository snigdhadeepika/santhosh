package com.cognizant.dto;

public enum Budget {
	
	HOTEL(30000),FLIGHT(20000),CAB(3000),TRAIN(6000),BUS(1500);
	int val;
	private Budget(int val) {
		this.val=val;
	}
	
	public double getVal() {
		return val;
	}

}
