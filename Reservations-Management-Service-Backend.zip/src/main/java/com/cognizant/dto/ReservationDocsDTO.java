package com.cognizant.dto;


import java.util.List;

import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Component;
@Getter
@Setter
@Component
public class ReservationDocsDTO {
	
	private int id;
	private int reservationId;
	private String documentURL;




}
