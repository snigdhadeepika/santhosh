package com.cognizant.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.entities.ReservationTypes;
import org.springframework.stereotype.Repository;


@Repository
public interface ReservationTypesRepository extends CrudRepository<ReservationTypes,Integer>{
	

}
