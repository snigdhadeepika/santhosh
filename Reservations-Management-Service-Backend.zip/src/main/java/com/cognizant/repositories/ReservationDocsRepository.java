package com.cognizant.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entities.ReservationDocs;

@Repository
public interface ReservationDocsRepository extends CrudRepository<ReservationDocs,Integer> {

}
