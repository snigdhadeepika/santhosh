package com.cognizant.repositories;


import java.util.List;
import java.util.Optional;

import org.hibernate.annotations.processing.Find;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entities.Reservations;


@Repository
public interface ReservationsRepository extends CrudRepository<Reservations,Integer>{

   public List<Reservations> findByTravelRequestId(int travelRequestId);
  
  
   

}
