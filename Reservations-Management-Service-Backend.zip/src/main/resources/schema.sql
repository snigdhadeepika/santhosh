
create table Reservation_Types(
Type_Id int,
Type_Name varchar(25),
Constraint PK_Reservation_Types Primary Key(Type_Id)
);


create table Reservations(
Id integer auto_increment,
Reservation_Done_By_Employee_Id integer,
Travel_Request_Id integer,
Reservation_Type_Id integer,
Created_On date,
Reservation_Done_With_Entity varchar(50),
Reservation_Date date,
Amount integer,
Confirmation_Id varchar(10),
Remarks varchar(100),
Constraint PK_Reservations Primary Key(Id),
Constraint FK_Reservations_Reservation_Types Foreign Key(Reservation_Type_Id) References Reservation_Types(Type_Id)
);

create table Reservation_Docs(
Id integer auto_increment,
Reservation_Id integer,
Document_Url varchar(200),
Constraint PK_Reservation_Docs Primary Key(Id),
Constraint FK_Reservation_Docs_Reservation Foreign Key(Reservation_Id) References Reservations(Id)
);
create table Users(
Username varchar(40),
Password varchar(40) not null,
Role varchar(40) not null,
Is_Account_Locked boolean
);

