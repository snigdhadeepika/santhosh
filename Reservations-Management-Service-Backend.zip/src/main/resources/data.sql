insert into Reservation_Types(Type_Id,Type_Name) values(
1,'flight'),
(2,'train'),
(3,'bus'),
(4,'cab'),
(5,'hotel');

insert into Users values('Anurag','anurag2002','TravelDeskExec',false);
insert into Users values('Santhosh','santhosh1234','Employee',false);