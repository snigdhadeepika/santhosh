export interface AddReservations {
    reservationDoneByEmployeeId: number,
    travelRequestId: number,
    reservationDoneWithEntity: string,
    reservationDate: string,
    amount: number,
    confirmationID: string,
    remarks: string,
    documentURLS: string[],
    fromDate: string

}