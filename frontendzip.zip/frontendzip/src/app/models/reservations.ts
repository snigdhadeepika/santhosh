export interface Reservations {
    id: number,
    reservationDoneByEmployeeId: number,
    travelRequestId: number,
    reservationDoneWithEntity: string,
    reservationDate: string,
    amount: number,
    confirmationID: string,
    createdOn: string,
    remarks: string
}