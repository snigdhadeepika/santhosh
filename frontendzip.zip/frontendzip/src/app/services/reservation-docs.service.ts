import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ReservationDocsService {

  constructor(private http: HttpClient) { }

  private getAllReservationDocumentsDetailsURL = 'http://localhost:8091/api/reservations/'

  public getAllReservationDocumentsDetails(id: number) {
    return this.http.get<string[]>(this.getAllReservationDocumentsDetailsURL + id + "/download");
  }
}
