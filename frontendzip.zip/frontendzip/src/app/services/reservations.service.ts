import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Reservations } from '../models/reservations';
import { FormGroup } from '@angular/forms';
import { AddReservations } from '../models/addReservation';

@Injectable({
  providedIn: 'root'
})
export class ReservationsService {

  constructor(private http: HttpClient) { }

  private addNewReservationsURL = 'http://localhost:8091/api/reservations/add';
  private getAllTravelReservationsURL = 'http://localhost:8091/api/reservations/track/'
  private getAllReservationsURL = 'http://localhost:8091/api/reservations/'

  public addNewReservationsRequest(addReservation: AddReservations) {
    return this.http.post<string>(this.addNewReservationsURL, addReservation, { responseType: 'text' as 'json' });
  }
  public getAllTravelReservationsRequest(travelRequestId: number) {
    return this.http.get<Reservations[]>(this.getAllTravelReservationsURL + travelRequestId);
  }
  public getAllReservationRequest(id: number) {
    return this.http.get<Reservations>(this.getAllReservationsURL + id);
  }
}
