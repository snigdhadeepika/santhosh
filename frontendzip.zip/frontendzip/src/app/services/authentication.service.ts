import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { first, Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private http: HttpClient) { }

  private authenticationURL: string = "http://localhost:8091/authenticate/users";

  user!: User;
  userBackend!: User;
  authenticated!: boolean;


  authenticate(username: string, password: string): Observable<boolean> {
    console.log("in auth:" + username);
    console.log("in auth:" + password);
    this.user = new User();
    this.user.username = username;
    this.user.password = password;

    return new Observable<boolean>((observer) => {
      this.getUser(this.user).pipe(first()).subscribe((data) => {
        console.log(data);
        this.userBackend = new User();
        this.userBackend.username = data.username;
        this.userBackend.password = data.password;
        this.userBackend.role = data.role;
        if (this.user.username === this.userBackend.username && this.user.password == this.userBackend.password) {
          this.authenticated = true;
          sessionStorage.setItem('username', username);
          sessionStorage.setItem('role', this.userBackend.role);
        } else {
          this.authenticated = false;
        }
        observer.next(this.authenticated);
        observer.complete();
      });
    });
  }


  getUser(user: any) {
    return this.http.post<User>(this.authenticationURL, user);
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    let role = sessionStorage.getItem('role');
    console.log(!(user === null))
    return !(user === null && role === null);

  }

  isUserEmployee() {
    let role = sessionStorage.getItem('role');
    return (role === 'Employee');
  }

  isUserNotEmployee() {
    let role = sessionStorage.getItem('role');
    return (role === 'TravelDeskExec');
  }


  logOut() {
    sessionStorage.removeItem('username')
    sessionStorage.removeItem('role');
  }
}