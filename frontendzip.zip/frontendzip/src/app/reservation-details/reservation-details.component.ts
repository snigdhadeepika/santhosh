import { Component, OnInit } from '@angular/core';
import { Reservations } from '../models/reservations';
import { ActivatedRoute } from '@angular/router';
import { ReservationsService } from '../services/reservations.service';
import { ReservationDocsService } from '../services/reservation-docs.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-reservation-details',
  templateUrl: './reservation-details.component.html',
  styleUrl: './reservation-details.component.css'
})
export class ReservationDetailsComponent implements OnInit {
  reservation!: Reservations;

  constructor(private route: ActivatedRoute, private reservationsService: ReservationsService, private reservationDocsService: ReservationDocsService) { }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.reservationsService.getAllReservationRequest(id).subscribe(
      (reservation: Reservations) => {
        this.reservation = reservation;
      }
    );
  }
  public downloadDocuments(id: number) {
    this.reservationDocsService.getAllReservationDocumentsDetails(id).subscribe(
      (urls: string[]) => {
        urls.forEach(url => {
          fetch(url)
            .then(response => response.blob())
            .then(blob => {
              let filename = url.substring(url.lastIndexOf("files/") + 6);
              saveAs(blob, filename);
            })
        });
      }
    );
  }
}
